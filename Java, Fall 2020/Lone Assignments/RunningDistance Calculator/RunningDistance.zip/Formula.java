/*
Name: Kaan Montplaisir
UIN: 627003014
Date: 11/3/2020
Assignment: RunningDistance Calculator

Okay, so, in World of Warcraft, the user runs at 7 yards per second, which is 6.4 meters per second
the calculation portion will take the user input, turn it into a double preemptively, and then divide the user input by 6.4 to find out how long it would take.
*/

class Formula {
  public double Formula(double distanceinm) {
    double value = distanceinm/6.40;
    return value;
  } //end main
} //end class
